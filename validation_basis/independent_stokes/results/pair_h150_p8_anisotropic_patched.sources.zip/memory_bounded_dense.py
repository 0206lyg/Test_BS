"""File-backed dense reference solve without a second resident dense matrix.

This changes storage only. The operator is the original fmm3dbie exterior
combined-layer matrix, assembled by the same routine as Backend.matrix.
Two separate files retain the original operator and its LU factorization.
Both are removed by default, including after failure; after preflight checks
pass, a JSON stage record is retained. Disk-backed storage does not qualify
the physical solution.
"""
from __future__ import annotations

import json
import mmap
import os
from pathlib import Path
import shutil
import tempfile
import time
import warnings

import numpy as np
from scipy import __version__ as scipy_version
from scipy.linalg import LinAlgWarning, lu_factor, lu_solve


class MMapDenseError(RuntimeError):
    def __init__(self, message, diagnostics):
        self.diagnostics = diagnostics
        super().__init__(message)


def _write_record(path, record):
    temporary = path.with_suffix('.json.tmp')
    temporary.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    temporary.replace(path)


def _drop_clean_pages(mapping, path, record):
    """Best-effort cache advice; correctness never depends on OS eviction."""
    mapping.flush()
    try:
        mapping._mmap.madvise(mmap.MADV_DONTNEED)
        record['madvise_dontneed_supported'] = True
    except (AttributeError, OSError, ValueError):
        record['madvise_dontneed_supported'] = False
    if hasattr(os, 'posix_fadvise'):
        fd = os.open(path, os.O_RDONLY)
        try:
            os.posix_fadvise(fd, 0, 0, os.POSIX_FADV_DONTNEED)
            record['posix_fadvise_dontneed_supported'] = True
        except OSError:
            record['posix_fadvise_dontneed_supported'] = False
        finally:
            os.close(fd)


def solve_mmap_dense(backend, mesh, rhs, eps, workdir, alpha=1., beta=1.,
                     max_memory_gb=9., keep_matrices=False, chunk_columns=256,
                     disk_reserve_gb=.5, progress=None):
    """Return ``(solution, diagnostics)`` using two Fortran-order mmap files.

    ``rhs`` has shape (3*N,nrhs), or (3*N,). ``progress(stage, record_copy)``
    receives preparation/assembly/factor/solve/residual status updates. Native
    output/warnings should be captured by the caller around this function.

    Memory guards cover the near-quadrature heap estimate, one resident LU,
    and bounded copying/verification buffers. File pages remain OS-managed;
    these estimates are not a hard RSS cap or a guarantee against OOM from
    other processes. No call to Backend.matrix's in-memory allocator is made.
    """
    n = int(mesh['srcvals'].shape[1])
    d = 3*n
    rhs = np.asarray(rhs, dtype=np.float64)
    was_vector = rhs.ndim == 1
    if was_vector:
        rhs = rhs[:, None]
    if rhs.ndim != 2 or rhs.shape[0] != d or rhs.shape[1] < 1 or not np.isfinite(rhs).all():
        raise ValueError('rhs must be finite with shape (3*N,nrhs)')
    if not (n > 0 and 0 < eps < 1 and np.isfinite(alpha) and np.isfinite(beta)
            and alpha > 0 and beta > 0 and np.isfinite(max_memory_gb) and max_memory_gb > 0):
        raise ValueError('Positive finite exterior operator parameters and memory budget required')
    if int(chunk_columns) != chunk_columns or chunk_columns < 1:
        raise ValueError('chunk_columns must be a positive integer')
    if not np.isfinite(disk_reserve_gb) or disk_reserve_gb < 0:
        raise ValueError('disk_reserve_gb must be finite and nonnegative')
    chunk_columns = min(int(chunk_columns), d)
    matrix_bytes = 8*d*d
    vector_bytes = rhs.nbytes
    # Upstream stores 6 kernels plus one scalar-kernel temporary. Native
    # indexing, geometric work, LAPACK work and allocator overhead get slack.
    slack = 256*1024**2
    assembly_heap = 56*n*n+16*n*len(mesh['norders'])+slack
    factor_working = matrix_bytes+8*d*chunk_columns+8*vector_bytes+slack
    memory_needed = max(assembly_heap, factor_working)
    if memory_needed > max_memory_gb*1e9:
        raise MemoryError(f'Mmap dense estimated working memory {memory_needed/1e9:.3f} GB '
                          f'exceeds budget {max_memory_gb:g} GB; file pages are OS-managed')
    workdir = Path(workdir).expanduser().resolve()
    workdir.mkdir(parents=True, exist_ok=True)
    disk_free = shutil.disk_usage(workdir).free
    disk_needed = 2*matrix_bytes+int(disk_reserve_gb*1e9)
    if disk_free < disk_needed:
        raise OSError(f'Mmap dense needs {disk_needed/1e9:.3f} GB free disk including reserve; '
                      f'only {disk_free/1e9:.3f} GB available')
    folder = Path(tempfile.mkdtemp(prefix='mmap_dense_', dir=workdir))
    operator_path, lu_path = folder/'operator.f64', folder/'lu.f64'
    record_path = folder/'diagnostics.json'
    record = {'schema': 'independent_stokes_mmap_dense_v1', 'status': 'preparing',
              'node_count': n, 'dof_count': d, 'rhs_count': rhs.shape[1],
              'alpha': float(alpha), 'beta': float(beta), 'quadrature_tolerance': float(eps),
              'operator_path': str(operator_path), 'lu_path': str(lu_path),
              'matrix_dtype': 'float64', 'matrix_order': 'F',
              'backend_library': str(getattr(backend, 'path', 'unspecified')),
              'numpy_version': np.__version__, 'scipy_version': scipy_version,
              'diagnostics_path': str(record_path), 'matrix_bytes_each': matrix_bytes,
              'estimated_assembly_heap_bytes': assembly_heap,
              'estimated_factor_working_bytes': factor_working,
              'memory_budget_bytes': int(max_memory_gb*1e9),
              'disk_free_at_start_bytes': disk_free, 'disk_needed_bytes': disk_needed,
              'chunk_columns': chunk_columns, 'keep_matrices': bool(keep_matrices),
              'lu_aliases_memmap': None, 'physical_accuracy_qualified': False,
              'timings_seconds': {}}
    started = time.monotonic()
    operator_map = lu_map = lu = None

    def stage(name):
        record['status'] = name
        record['elapsed_seconds'] = time.monotonic()-started
        _write_record(record_path, record)
        if progress is not None:
            progress(name, json.loads(json.dumps(record)))

    try:
        stage('assembling')
        operator_map = np.memmap(operator_path, dtype=np.float64, mode='w+', shape=(d,d), order='F')
        t = time.monotonic()
        backend.call('stok_comb_vel_matgen', len(mesh['norders']), mesh['norders'],
                     mesh['ixyzs'], mesh['iptype'], n, mesh['srccoefs'],
                     mesh['srcvals'], float(eps), np.array([alpha, beta]), 1, operator_map)
        record['timings_seconds']['assembly'] = time.monotonic()-t
        _drop_clean_pages(operator_map, operator_path, record)
        stage('copying_for_lu')
        lu_map = np.memmap(lu_path, dtype=np.float64, mode='w+', shape=(d,d), order='F')
        t = time.monotonic()
        for first in range(0, d, chunk_columns):
            last = min(first+chunk_columns, d)
            block = operator_map[:, first:last]
            if not np.isfinite(block).all():
                raise FloatingPointError('Non-finite assembled matrix')
            lu_map[:, first:last] = block
            del block
            _drop_clean_pages(operator_map, operator_path, record)
            _drop_clean_pages(lu_map, lu_path, record)
        record['timings_seconds']['copy_and_finite_check'] = time.monotonic()-t
        operator_map._mmap.close()
        operator_map = None
        stage('factorizing')
        t = time.monotonic()
        # Native float64 + F-contiguous ndarray + overwrite_a=True is LAPACK's
        # in-place path. Check aliasing explicitly instead of assuming it.
        with warnings.catch_warnings():
            warnings.simplefilter('error', LinAlgWarning)
            lu, pivots = lu_factor(np.asarray(lu_map), overwrite_a=True, check_finite=False)
        record['lu_aliases_memmap'] = bool(np.shares_memory(lu, lu_map))
        if not record['lu_aliases_memmap']:
            raise RuntimeError('SciPy copied the LU matrix; in-place storage contract failed')
        record['timings_seconds']['factorization'] = time.monotonic()-t
        stage('solving')
        t = time.monotonic()
        solution = lu_solve((lu,pivots), rhs, check_finite=False)
        if not np.isfinite(solution).all():
            raise FloatingPointError('Non-finite dense solution')
        record['timings_seconds']['solve'] = time.monotonic()-t
        del lu
        lu = None
        _drop_clean_pages(lu_map, lu_path, record)
        lu_map._mmap.close()
        lu_map = None
        stage('checking_residual')
        t = time.monotonic()
        operator_map = np.memmap(operator_path, dtype=np.float64, mode='r', shape=(d,d), order='F')
        residual = -rhs.copy()
        for first in range(0, d, chunk_columns):
            last = min(first+chunk_columns, d)
            residual += operator_map[:, first:last] @ solution[first:last]
            _drop_clean_pages(operator_map, operator_path, record)
        if not np.isfinite(residual).all():
            raise FloatingPointError('Non-finite original-operator residual')
        norms = np.linalg.norm(rhs, axis=0)
        absolute = np.linalg.norm(residual, axis=0)
        relative = np.divide(absolute, norms, out=absolute.copy(), where=norms > 0)
        if not (np.isfinite(norms).all() and np.isfinite(absolute).all()
                and np.isfinite(relative).all()):
            raise FloatingPointError('Non-finite original-operator residual norm')
        record['absolute_residual_by_rhs'] = absolute.tolist()
        record['relative_residual_by_rhs'] = relative.tolist()
        record['relative_residual_max'] = float(np.max(relative))
        record['timings_seconds']['residual'] = time.monotonic()-t
        operator_map._mmap.close()
        operator_map = None
        stage('completed')
        return (solution[:,0] if was_vector else solution), record
    except BaseException as exc:
        record['status'] = 'failed'
        record['exception_type'] = type(exc).__name__
        record['exception_message'] = str(exc)
        record['elapsed_seconds'] = time.monotonic()-started
        _write_record(record_path, record)
        if isinstance(exc, (KeyboardInterrupt, SystemExit)):
            raise
        raise MMapDenseError(str(exc), record) from exc
    finally:
        lu = None
        for mapping in [operator_map, lu_map]:
            if mapping is not None:
                try:
                    mapping._mmap.close()
                except (BufferError, OSError):
                    pass
        if not keep_matrices:
            for path in [operator_path, lu_path]:
                path.unlink(missing_ok=True)
        record['matrix_files_retained'] = {str(path): path.exists() for path in [operator_path,lu_path]}
        _write_record(record_path, record)
